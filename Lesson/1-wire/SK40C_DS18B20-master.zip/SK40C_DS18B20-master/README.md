# SK40C_DS18B20
<h3>Description:</h3>
Sample Source code for SK40C+PIC16F877A with DS18B20 Temperature Sensor - Waterproof<br/>

<b>Tutorial:</b>
<ul><li><a href="http://tutorial.cytron.com.my/2012/11/01/ds18b20-temperature-sensor/" target="_blank">DS18B20 Temperature Sensor</a></li></ul>
<b>Hardware:</b>
<ul><li><a href="http://cytron.com.my/p-sn-ds18b20" target="_blank">Temperature Sensor - Waterproof</a></li>
<li><a href="http://cytron.com.my/p-sk40c" target="_blank">SK40C</a>+<a href="http://www.cytron.com.my/p-ic-pic-16f877a" target="_blank">PIC16F877A</a></li></ul>
<b>Software:</b>
<ul><li>MPLAB and HI-Tech C Compiler</li></ul>
Welcome to our <a href="http://forum.cytron.com.my" target="_blank">technical forum</a> for further inquiry.
